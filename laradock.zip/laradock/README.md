# Cài đặt môi trường

## Cài đặt docker

- https://docs.docker.com/install/

Đối với Linux cần cài thêm Docker-compoce

- https://docs.docker.com/compose/install/#prerequisites

# Clone dự án

```sh
$ git clone git@gitlab.com:azwebplus/fanalux-laradock.git laradock
# or
$ git clone https://gitlab.com/azwebplus/fanalux-laradock.git laradock
```

## Tạo biến mỗi trường

```sh
# Chạy một trong các lệnh sau, tùy theo môi trường
$ cp .env.dev .en
$ cp .env.test .en
$ cp .env.prod .en
```

# Hướng dẫn dự án.

## Chạy Docker Container

```sh
$ cp run.sh.dev run.sh
$ sh run.sh
```

## Thao tác với workspace

```sh
$ docker-compose exec workspace bash
# Or
$ sh workspace.sh
```

### Cấu hình nginx với laravel-echo-server

```sh
$ docker ps
$ docker inspect <container_id_of_laravel_echo_server> | grep "IPAddress"
# Lấy IP nhận được cấu hình cho file Nginx
```

## Cấu hình Nginx sử dụng với laravel-echo-server

frontend:
backend:
aliases: - api.fanalux.local - dev.fanalux.local
