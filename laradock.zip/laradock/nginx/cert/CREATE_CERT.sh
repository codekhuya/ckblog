# Chỉnh sửa những thông tin sau theo nhu cầu
cd $(dirname $0)
HOSTNAME="api.fanalux.local"  # 
COUNTRY=US
STATE="CA"
CITY="San Deago"
ORGANIZATION="AZWEBLUS Ltd."
ORGANIZATION_UNIT="Software Department"
EMAIL="admin@$HOSTNAME"
echo "[req]
default_bits = 2048
prompt = no
default_md = sha256 
x509_extensions = v3_req 
distinguished_name = dn 
[dn]
C = $COUNTRY
ST = $STATE
L = $CITY 
O = $ORGANIZATION 
OU = $ORGANIZATION_UNIT 
emailAddress = $EMAIL 
CN = $HOSTNAME 
[v3_req] 
subjectAltName = @alt_names 
[alt_names] 
DNS.1 = *.$HOSTNAME 
DNS.2 = $HOSTNAME" > "$HOSTNAME.cnf"  
openssl req -new -x509 -newkey rsa:2048 -sha256 -nodes -keyout "$HOSTNAME.key" -days 3560 -out "$HOSTNAME.crt" -config "$HOSTNAME.cnf"