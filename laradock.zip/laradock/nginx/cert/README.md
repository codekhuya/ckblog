# Hướng dẫn cài đặt

Mở file CREATE_CERT, chỉnh sửa thông tin rồi chạy lệnh

```sh
$ sh CREATE_CERT.sh
```

Để đăng ký self cert cần đăng ký CERT vào máy tính theo môi trường.

```sh
# LINUX
https://leehblue.com/add-self-signed-ssl-google-chrome-ubuntu-16-04/

# Windows
Kích đôi lên file *.crt để tiến hành đăng ký.
```
