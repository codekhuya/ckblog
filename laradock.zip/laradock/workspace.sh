echo START: Preparing to start docker-compose

cd $(dirname $0)

docker-compose exec --user=laradock workspace bash
