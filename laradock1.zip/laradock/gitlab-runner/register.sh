gitlab-runner verify --delete
 
gitlab-runner register \
  --non-interactive \
  --url "https://gitlab.com/" \
  --registration-token "wTuakUP5mv3sLEDXkJgz" \
  --executor "shell" \
  --description "Laradock docker gitlab-runner for group fanalux 4" \
  --tag-list "docker,aws" \
  --run-untagged \
  --locked="false"

gitlab-runner status
# gitlab-runner uninstall
# gitlab-runner start
# gitlab-runner install --user=root

# gitlab-runner run
# gitlab-runner verify --delete
# gitlab-runner list
