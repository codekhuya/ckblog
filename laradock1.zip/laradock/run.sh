echo START: Preparing to start docker-compose

cd $(dirname $0)

docker-compose up -d nginx mariadb redis laravel-echo-server phpmyadmin php-worker portainer workspace

echo FINISH: docker-compose started.

echo GO! GO! GO!
